# parcel-starter-scss

## How to install / Setup the starter
```
git clone https://github.com/davidvenin/parcel-starter-scss.git
cd parcel-starter-scss
npm install sass or yarn add sass
parcel index.html
```
